import autoRemoveName.GUI.MainPage as g

if __name__ == '__main__':
    window = g.MainPage()
    window.open_window()
