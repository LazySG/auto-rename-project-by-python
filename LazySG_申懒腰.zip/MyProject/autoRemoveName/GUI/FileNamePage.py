import os
import sys
import tkinter as tk
from tkinter import messagebox
from tkinter.filedialog import askdirectory
import autoRemoveName.GUI.FileMenu as fm
import autoRemoveName.GUI.MainPage as GUI
import autoRemoveName.excel.tools as exto


class FileNamePage:

    def __init__(self):
        self.root = tk.Tk()
        self.dir_path = None
        self.file_path = None

    def changeName(self, string: str):
        list = string.split('\\')
        str1 = ''
        for i in range(len(list) - 1):
            str1 += list[i] + '\\\\'
        # 减1是因为下标偏移量
        str1 += list[len(list) - 1]
        return str1

    def selectPath_dir(self):
        path_ = askdirectory()
        if path_ == '':
            self.path_dir.get()
        else:
            path_ = path_.replace('/', '\\')
            self.path_dir.set(path_)

    def selectPath_file(self):
        path_ = askdirectory()
        if path_ == '':
            self.path_file.get()
        else:
            path_ = path_.replace('/', '\\')
            self.path_file.set(path_)

    def submit(self):
        # 把文件路径改为python看得懂的路径
        # self.dir_path 是Entry类,需要get方法转换成字符串
        dir_path = self.changeName(self.dir_path.get())
        file_path = self.changeName(self.file_path.get())
        # 如果路径为空，则抛出异常 v0.0.2
        if dir_path == '' or file_path == '':
            tk.messagebox.showerror('路径错误', '文件夹路径或文件路径为空')
        assert dir_path != '' and file_path != '', "路径为空"
        # 获取文件夹中所有文件名的序列
        newName = os.listdir(dir_path)
        ex = exto.ExcelTools(None, len(newName))
        # 去除文件后缀名
        name_list = ex.deleteSuffix(newName)
        # 将文件写入指定路径的文件中
        ex.writeFileName(name_list, file_path)
        # 提示
        tk.messagebox.showinfo('文件生成成功!', '文件已成功生成!!!')
        # else:
        #     print("路径为空")

    # temp.writeFileName()
    def comeBack(self):
        if self.root is not None:
            # 清空页面
            self.root.destroy()
            # 匿名对象，用完就丢
            GUI.MainPage().open_window()
        else:
            print('翻页失败')

    def open_FileNamePage(self):

        # path_为字符串对象
        # 必须放在这个位置，如果放到__init__中刷新后不会重置
        self.path_dir = tk.StringVar()
        self.path_file = tk.StringVar()

        self.root.title('一键获取文件名 v0.1.1')
        self.root.geometry('500x300+500+250')
        # 匿名对象调用菜单
        fm.FileMenu(self.root).open_fileMenuWindow()
        # 选择路径
        # 需要获取的文件夹路径
        lbl1 = tk.Label(self.root, text='需要获取的文件夹路径为：', font=('宋体', 10))
        lbl1.place(relx=0, rely=0.2, relwidth=0.4, relheight=0.2)
        # 文本框
        self.dir_path = tk.Entry(self.root, textvariable=self.path_dir)
        self.dir_path.place(relx=0.4, rely=0.25, relwidth=0.5, relheight=0.1)
        # 浏览按钮
        but1 = tk.Button(self.root, text='浏览', command=self.selectPath_dir)
        but1.place(relx=0.9, rely=0.25, relwidth=0.09, relheight=0.1)
        # 生成的文件路径
        lbl2 = tk.Label(self.root, text='生成的文件路径为：', font=('宋体', 10))
        lbl2.place(relx=0, rely=0.5, relwidth=0.4, relheight=0.2)
        # 文本框
        self.file_path = tk.Entry(self.root, textvariable=self.path_file)
        self.file_path.place(relx=0.4, rely=0.55, relwidth=0.5, relheight=0.1)
        # 浏览按钮
        but2 = tk.Button(self.root, text='浏览', command=self.selectPath_file)
        but2.place(relx=0.9, rely=0.55, relwidth=0.09, relheight=0.1)
        # 按钮
        button1 = tk.Button(self.root, text='一键生成', command=self.submit)
        button1.place(relx=0.33, rely=0.75, width=60, height=25)
        # 刷新按钮
        button2 = tk.Button(self.root, text='重置', command=self.open_FileNamePage)
        button2.place(relx=0.53, rely=0.75, width=60, height=25)
        # 返回按钮
        comeBack = tk.Button(self.root, text='返回', command=self.comeBack)
        comeBack.place(relx=0, rely=0.9, width=60, height=25)
        # 退出按钮
        exitButton = tk.Button(self.root, text='退出', command=sys.exit)
        exitButton.place(relx=0.88, rely=0.9, width=60, height=25)
        # 进入主程序循环事件
        self.root.mainloop()


if __name__ == '__main__':
    FileNamePage().open_FileNamePage()
