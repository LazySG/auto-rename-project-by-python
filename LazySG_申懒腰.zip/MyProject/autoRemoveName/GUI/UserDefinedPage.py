import sys
import tkinter as tk
import xlrd
from tkinter import filedialog
from tkinter import messagebox
from tkinter.filedialog import askdirectory
import autoRemoveName.GUI.MainPage as GUI
import autoRemoveName.excel.tools as exto
import autoRemoveName.autoRename.tools as to
import autoRemoveName.GUI.FileMenu as fm


class UserDefinedPage:
    def __init__(self):
        self.root = tk.Tk()
        # _path为对象
        self.dir_path = None
        self.file_path = None

    def changeName(self, string: str):
        list = string.split('\\')
        str1 = ''
        for i in range(len(list) - 1):
            str1 += list[i] + '\\\\'
        # 减1是因为下标偏移量
        str1 += list[len(list) - 1]
        return str1

    def comeBack(self):
        if self.root is not None:
            # 清空页面
            self.root.destroy()
            # 匿名对象，用完就丢
            GUI.MainPage().open_window()
        else:
            print('翻页失败')

    def selectPath_dir(self):
        # 文件夹路径
        path_ = askdirectory()
        if path_ == '':
            self.path_dir.get()
        else:
            path_ = path_.replace('/', '\\')
            self.path_dir.set(path_)

    def selectPath_file(self):
        # 文件路径
        path_ = filedialog.askopenfilename()
        if path_ == '':
            self.path_file.get()
        else:
            path_ = path_.replace('/', '\\')
            self.path_file.set(path_)

    def sumbit(self):
        # 把文件路径改为python看得懂的路径
        # self.dir_path 是Entry类,需要get方法转换成字符串
        dir_path = self.changeName(self.dir_path.get())
        file_path = self.changeName(self.file_path.get())
        # 如果路径为空，则抛出异常 v0.0.2
        if dir_path == '' or file_path == '':
            tk.messagebox.showerror('路径错误', '文件夹路径或文件路径为空')
        assert dir_path != '' and file_path != '', "路径为空"
        # 打开文件
        data = xlrd.open_workbook(filename=file_path)
        # 多少行
        table = data.sheets()[0]
        nrows = table.nrows  # 多少行
        # 获取文件夹中所有文件名的序列
        ex = exto.ExcelTools(table, nrows)
        rn = to.Tools(dir_path)
        # 新命名后的列表
        # char 为分隔符， last为后缀
        print(self.char)
        name_list = ex.getNewNameList(self.char.get(), self.last.get())
        # 改名
        rn.renamee(nrows, name_list)
        # 提示
        tk.messagebox.showinfo('命名成功!', '文件已成功重命名!!!')

    def open_userDefinedPage(self):

        # path_为字符串对象
        # 必须放在这个位置，如果放到__init__中刷新后不会重置
        self.path_dir = tk.StringVar()
        self.path_file = tk.StringVar()
        self.char = tk.StringVar()
        self.last = tk.StringVar()

        self.root.geometry('500x300+500+250')
        self.root.title('自定义重命名 v0.1.1')
        # 匿名对象调用菜单
        fm.FileMenu(self.root).open_fileMenuWindow()
        # 分隔符
        ch1 = tk.Label(self.root, text='分隔符：', font=('宋体', 10))
        ch1.place(relx=0.2, rely=0.15, relwidth=0.2, relheight=0.1)
        # 文本框
        char = tk.Entry(self.root, textvariable=self.char)
        char.place(relx=0.35, rely=0.15, relwidth=0.1, relheight=0.1)
        # 文件后缀
        ch2 = tk.Label(self.root, text='文件后缀：', font=('宋体', 10))
        ch2.place(relx=0.5, rely=0.15, relwidth=0.2, relheight=0.1)
        # 文本框
        last = tk.Entry(self.root, textvariable=self.last)
        last.place(relx=0.66, rely=0.15, relwidth=0.1, relheight=0.1)
        # 选择路径
        # 需要获取的文件夹路径
        lbl1 = tk.Label(self.root, text='需要改名的文件夹路径为：', font=('宋体', 10))
        lbl1.place(relx=0, rely=0.3, relwidth=0.4, relheight=0.2)
        # 浏览按钮
        but1 = tk.Button(self.root, text='浏览', command=self.selectPath_dir)
        but1.place(relx=0.9, rely=0.35, relwidth=0.09, relheight=0.1)
        # 文本框
        self.dir_path = tk.Entry(self.root, textvariable=self.path_dir)
        self.dir_path.place(relx=0.4, rely=0.35, relwidth=0.5, relheight=0.1)
        # 浏览按钮
        but2 = tk.Button(self.root, text='浏览', command=self.selectPath_file)
        but2.place(relx=0.9, rely=0.55, relwidth=0.09, relheight=0.1)
        # 生成的文件路径
        lbl2 = tk.Label(self.root, text='命名文件xls路径为：', font=('宋体', 10))
        lbl2.place(relx=0, rely=0.5, relwidth=0.4, relheight=0.2)
        # 文本框
        self.file_path = tk.Entry(self.root, textvariable=self.path_file)
        self.file_path.place(relx=0.4, rely=0.55, relwidth=0.5, relheight=0.1)

        # 按钮
        button1 = tk.Button(self.root, text='一键重命名', command=self.sumbit)
        button1.place(relx=0.33, rely=0.75, width=70, height=25)
        # 刷新按钮
        button2 = tk.Button(self.root, text='重置', command=self.open_userDefinedPage)
        button2.place(relx=0.53, rely=0.75, width=60, height=25)
        # 返回按钮
        comeBack = tk.Button(self.root, text='返回', command=self.comeBack)
        comeBack.place(relx=0, rely=0.9, width=60, height=25)
        # 退出按钮
        exitButton = tk.Button(self.root, text='退出', command=sys.exit)
        exitButton.place(relx=0.88, rely=0.9, width=60, height=25)
        # 进入主程序循环事件
        self.root.mainloop()


if __name__ == '__main__':
    UserDefinedPage().open_userDefinedPage()
