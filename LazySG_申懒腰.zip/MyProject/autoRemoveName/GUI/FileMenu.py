from tkinter import *


class FileMenu:

    def __init__(self, root):
        self.root = root

    def introduce(self):
        root = Tk()
        root.title('功能介绍')
        root.geometry('565x300+500+250')
        txt = Text(root)
        scroll = Scrollbar(root, command=txt.yview)
        txt.configure(yscrollcommand=scroll.set)
        txt.tag_configure('正文', font=('楷体', 16, 'bold'))
        txt.tag_configure('标题', font=('黑体', 20, 'bold'))
        txt.tag_configure('落款', foreground='#476042', font=('华文仿宋', 12, 'bold'))
        txt.insert(END, '\n\t\t         功能介绍\n', '标题')
        quote = """
    你是否在担任过班委？在收集同学们提交的截图或是作业时？是否常常遇到过文件命名总是错，文件格式不正确的情况？
    该软件将解决你的烦恼，快速知道多少人交了作业，哪些同学交了作业，让文件命名可以被批量统计以及批量修改，软件中采用了面向对象的编程思想，将内容拆分成一个一个模块，方便后期的管理和维护。
                """
        txt.insert(END, quote, '正文')
        txt.insert(END, '\n\t\t\t 最后更新时间为 2022-6-9', '落款')
        txt.pack()
        scroll.pack(side=RIGHT, fill=Y)
        root.mainloop()

    def usage(self):
        root = Tk()
        root.title('如何使用')
        root.geometry('565x300+500+250')
        txt = Text(root)
        scroll = Scrollbar(root, command=txt.yview)
        txt.configure(yscrollcommand=scroll.set)
        txt.tag_configure('正文', font=('楷体', 14, 'bold'))
        txt.tag_configure('标题', font=('黑体', 18, 'bold'))
        txt.tag_configure('落款', foreground='#476042', font=('华文仿宋', 12, 'bold'))
        txt.insert(END, '\n\t\t         如何使用\n', '标题')
        quote = """
    一键获取文件名：点击后会看到一个新页面，其中有两个文本框，一个是需要获取的文件夹路径，另一个是生成的文件路径，填写第一个会把该路径下的所有文件名去掉后缀并放入一个名为 Message.xls 的excel表中，生成的文件路径即为Message.xls的保存路径，填写后会在该路径文件夹下生成名为Message.xls的文件，Message.xls文件中存放的就是需要获取的文件夹路径中的所有文件去除后缀的名字。下方的刷新会清空路径内容，一键生成则会执行操作生成Message.xls文件，如果路径为空会抛出异常和错误提示，如果成功也会有提示。左下角的返回会回到上一个页面，退出就终止程序。

    自定义重命名：点击会看到分隔符，文件后缀名，文件夹路径和xls路径。其中命名规则是用分隔符把excel表某行对应的列的全部内容用分隔符连接在一起，再加上文件后缀，如果填默认为空字符串。文件夹路径为需要改名的所有文件所在的文件夹。文件xls路径为存放提前命名好名字的excel文件，点击一键重命名即可执行。

        """
        txt.insert(END, quote, '正文')
        txt.insert(END, '\n\t\t\t 最后更新时间为 2022-6-9', '落款')
        txt.pack()
        scroll.pack(side=RIGHT, fill=Y)
        root.mainloop()

    def about(self):
        root = Tk()
        root.title('关于')
        root.geometry('565x300+500+250')
        txt = Text(root)
        scroll = Scrollbar(root, command=txt.yview)
        txt.configure(yscrollcommand=scroll.set)
        txt.tag_configure('正文', font=('楷体', 16, 'bold'))
        txt.tag_configure('标题', font=('黑体', 20, 'bold'))
        txt.tag_configure('落款', foreground='#476042', font=('华文仿宋', 12, 'bold'))
        txt.insert(END, '\n\t\t         关于\n', '标题')
        quote = """
    当前版本v 0.1.1
    
    新增了菜单,实现用户可以一边使用软件一边观看说明书
    
    未来预计的更新内容：优化重命名的算法，从顺序遍历改用哈希表实现字典绑定,避免文件对应错误问题
    
    目前bug：返回会回到固定位置
                """
        txt.insert(END, quote, '正文')
        txt.insert(END, '作者：申懒腰\n\t\t\t     作者qq：1412862199\n\t\t\t 最后更新时间为 2022-6-9', '落款')
        txt.pack()
        scroll.pack(side=RIGHT, fill=Y)
        root.mainloop()

    def open_fileMenuWindow(self):
        menubar = Menu(self.root)
        fileMenu = Menu(menubar, tearoff=False)
        fileMenu.add_command(label="功能介绍", command=self.introduce)
        fileMenu.add_command(label="如何使用", command=self.usage)
        fileMenu.add_separator()
        fileMenu.add_command(label="关于", command=self.about)
        menubar.add_cascade(label='Help(帮助)', menu=fileMenu)
        self.root.config(menu=menubar)
