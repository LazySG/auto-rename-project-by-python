import sys
import tkinter as tk
import autoRemoveName.GUI.FileMenu as fm
import autoRemoveName.GUI.FileNamePage as fnp
import autoRemoveName.GUI.UserDefinedPage as user


class MainPage:

    def __init__(self):
        self.root = tk.Tk()

    def getFileNamePage(self):
        if self.root is not None:
            self.root.destroy()
            # 匿名对象，用完就丢
            fnp.FileNamePage().open_FileNamePage()
        else:
            print('翻页失败')

    def getUserDefinedPage(self):
        if self.root is not None:
            self.root.destroy()
            # 匿名对象，用完就丢
            user.UserDefinedPage().open_userDefinedPage()
        else:
            print('翻页失败')

    def open_window(self):
        self.root.geometry('500x300+500+250')
        self.root.title('文件修改器 v0.1.1')
        # 匿名对象调用菜单
        fm.FileMenu(self.root).open_fileMenuWindow()
        # popmenu = tk.Menu(self.root)
        #
        # fileMenu = tk.Menu(popmenu, tearoff=False)
        # fileMenu.add_command(lable='帮助')
        # self.root.config(menu=popmenu)
        lbl = tk.Label(self.root, text='欢迎使用文件名修改器', font=40)
        lbl.place(relx=0.3, rely=0.2, relwidth=0.4, relheight=0.1)

        button1 = tk.Button(self.root, text='一件获取文件名', command=self.getFileNamePage)
        button1.place(relx=0.2, rely=0.5, width=100, height=60)

        button2 = tk.Button(self.root, text='自定义重命名', command=self.getUserDefinedPage)
        button2.place(relx=0.6, rely=0.5, width=100, height=60)

        exitButton = tk.Button(self.root, text='退出', command=sys.exit)
        exitButton.place(relx=0.88, rely=0.9, width=60, height=25)
        self.root.mainloop()
        # lbl1 = tk.Label(root, text='需要重命名的文件名：')
        # lbl1.place(relx=0, rely=0.3, relwidth=0.4, relheight=0.2)
        #
        # e1 = tk.Entry(root)
        # e1.place(relx=0.4, rely=0.35, relwidth=0.3, relheight=0.1)
        #
        # lbl2 = tk.Label(root, text='更改后的文件名：')
        # lbl2.place(relx=0, rely=0.5, relwidth=0.4, relheight=0.2)
        #
        # e2 = tk.Entry(root)
        # e2.place(relx=0.4, rely=0.55, relwidth=0.3, relheight=0.1)
        #
        # button = tk.Button(root, text='确认更改', command=None)
        # button.place(relx=0.5, rely=0.8, width=60, height=30)


if __name__ == '__main__':
    window = MainPage()
    window.open_window()
