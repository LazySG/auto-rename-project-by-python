import xlwt


# 待修改, 将文件后缀去掉
class ExcelTools:

    def __init__(self, table, nrows):
        self.table = table
        self.nrows = nrows

    # 获取新名字
    #
    #          ch 表示char,为字符串分割的内容
    #          last 为文件后缀类型
    def getNewNameList(self, ch, last):
        # 用序列保存改好的名字
        newNameList = []
        # 遍历xls表格改名
        for i in range(self.nrows):
            tab1 = self.table.row_values(i, start_colx=0, end_colx=None)
            string = ''
            for t in tab1:
                string += str(t) + str(ch)
            if ch != '':
                string = string.rstrip(ch)
            if last != '':
                string += '.' + last
            newNameList.append(string)
            print(string)
        # print(newNameList)
        # reN.renamee(i, string)
        return newNameList

    # 后缀删除
    def deleteSuffix(self, name_list):
        new_list = []
        for name in name_list:
            string = ''
            temp = name.split('.')
            for i in range(len(temp) - 1):
                string += temp[i]
            new_list.append(string)
        return new_list

    # 获取excel中的名字
    def getExcelNameList(self):
        name_list = []
        for i in range(0, self.nrows, 1):
            name_list += self.table.row(i)[0]
        return name_list

    # 写入文件夹中的所有文件名到一个新的excel文件中
    def writeFileName(self, list_name, path):
        work_nook = xlwt.Workbook()
        work_sheet = work_nook.add_sheet('name')
        for i in range(0, self.nrows, 1):
            work_sheet.write(i, 0, list_name[i])
        work_nook.save(path + '\\\\Message.xls')

# 测试入口
# if __name__ == '__main__':
#     file = 'C:\\Users\\14128\\Desktop\\test\\cmd.xls'
#     data = xlrd.open_workbook(filename=file)
#     table = data.sheets()[0]
#     names = data.sheet_names()
#     nrows = table.nrows  # 多少行
#     print(nrows)
#     # tab = table.row_types(0, start_colx=0, end_colx=None)  # 把第0行的数据放入列表tab中
#     # print(tab)
#     photo_path = 'C:\\Users\\14128\\Desktop\\test\\photo'
#     ex = ExcelTools()
#     rn = RT.Tools(photo_path)
#     # 新命名后的列表
#     name_list = ex.getNewNameList('', 'jpg')
#     rn.renamee(nrows, name_list)
#     # 写入新的excel中
#     newName = os.listdir(photo_path)
#     ex.writeFileName(newName)

# print(tab1)
