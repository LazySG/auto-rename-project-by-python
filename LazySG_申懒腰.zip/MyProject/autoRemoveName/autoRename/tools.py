import os


class Tools:
    def __init__(self, fileDir):
        # 文件夹路径
        self.fileDir = fileDir

    # 批量交换名字的方法 rnows 表示行数， list_name是我存的新名字列表
    def renamee(self, rnows, list_name):
        # 将文件夹中的文件名全部存到list_path当中
        list_path = os.listdir(self.fileDir)
        # lastName = list_path[num].split(',')[0]
        # lastName = list_path[num]
        for i in range(0, rnows, 1):
            # 要改的文件名
            print(list_path[i])
            # 新名字
            print(list_name[i])
            if list_path[i] is not None and list_path[i] != list_name[i]:
                path = self.fileDir + '\\' + list_path[i]
                new_path = self.fileDir + '\\' + list_name[i]
                os.rename(path, new_path)
